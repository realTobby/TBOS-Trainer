﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Memory;

namespace TBOS_Trainer
{
    public partial class Form1 : Form
    {
        public Mem m = new Mem();

        public bool APPLICATION_RUNNING = false;

        public bool PLAYERBASE_FOUND = false;

        bool IsaacOpen = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            APPLICATION_RUNNING = true;
            if(!backgroundWorker1.IsBusy)
            {
                backgroundWorker1.RunWorkerAsync();
            }
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            try
            {
                while (APPLICATION_RUNNING)
                {
                    int IsaacId = m.getProcIDFromName("isaac-ng");
                    if (IsaacId > 0)
                        IsaacOpen = m.OpenProcess(IsaacId);

                    if (IsaacOpen == true)
                    {
                        this.Invoke(new MethodInvoker(() => this.label1.Text = "Found Binding of Isaac: Rebirth"));
                        this.Invoke(new MethodInvoker(() => this.label1.ForeColor = Color.Green));
                    }
                    else
                    {
                        this.Invoke(new MethodInvoker(() => this.label1.Text = "STATUS: Waiting for Binding of Isaac: Rebirth"));
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (IsaacOpen)
            {
                m.setFocus();

                

                var test = m.AoBScan("0", 0xffffffff, "?? ?? ?? ?? ?? 00 00 00 ?? 00 00 00 00 00 00 00 ?? ?? ?? ?? ?? ?? 00 00 03 00 00 00 ?? ?? ?? ?? 00 00 00 00 ?? 00 00 00 ?? ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 FF FF FF FF ?? 00 00 00");

                long pBase = test.Result;
                pBase -= 36;
            

                string str1;

                m.writeMemory(pBase.ToString("x8"), "byte", "0x" + Convert.ToInt64(16).ToString("X"));

                pBase += 4;

                m.writeMemory(pBase.ToString("x8"), "byte", "0x" + Convert.ToInt64(16).ToString("X"));

                /*
                Console.WriteLine("PlayerStruct Base Adress: 0x" + pBase.ToString("x8"));
                
                if(m.writeMemory("base+0x" + pBase.ToString("X") , "byte", "0x" + Convert.ToInt64(24).ToString("X")))
                    MessageBox.Show("Memory Write Was Successful!");
                else
                    MessageBox.Show("Memory Write Was Not Successful!");
                    */
                str1 = "0x" + pBase.ToString("x8") ;
                Console.WriteLine(str1);

                int b = m.readByte(str1);

                Console.WriteLine("MaxHearts: " + b.ToString());

                /*
                for(int i=0; i<0xffff; i++)
                {
                    Console.WriteLine(m.readByte((test.Result + i).ToString()));
                }
                */
            }
            
        }
    }
}

